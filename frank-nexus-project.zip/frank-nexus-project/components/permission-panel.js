/**
 * components/permission-panel.js
 * -----------------------------------------------------------------------
 * Renders the Permission Center panel and wires each row's "Request"
 * action to the corresponding NexusPermissions call. Purely presentational
 * — all actual permission logic lives in js/modules/permissions.js.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  const LABELS = {
    camera: 'Camera',
    microphone: 'Microphone',
    notifications: 'Notifications',
    location: 'Location',
    files: 'File Access',
  };

  function badge(name, status) {
    const label = status === 'granted' ? 'Granted' : status === 'denied' ? 'Denied' : 'Not Requested';
    const cls = status === 'granted' ? 'granted' : status === 'denied' ? 'denied' : 'not-requested';
    return `<span class="perm-badge ${cls}" data-perm="${name}">${label}</span>`;
  }

  function render() {
    const body = document.getElementById('permission-panel-body');
    if (!body) return;
    const status = NexusPermissions.getAll();
    body.innerHTML = Object.keys(LABELS)
      .map((name) => `
        <div class="perm-row">
          <span class="perm-name">${LABELS[name]}</span>
          ${badge(name, status[name])}
        </div>
      `)
      .join('');

    body.querySelectorAll('.perm-badge.not-requested').forEach((el) => {
      el.addEventListener('click', () => requestPermission(el.dataset.perm));
    });
  }

  async function requestPermission(name) {
    try {
      if (name === 'camera') {
        const stream = await NexusPermissions.requestCamera();
        stream.getTracks().forEach((t) => t.stop()); // just proving access, not keeping the camera on
      } else if (name === 'microphone') {
        const stream = await NexusPermissions.requestMicrophone();
        stream.getTracks().forEach((t) => t.stop());
      } else if (name === 'notifications') {
        await NexusPermissions.requestNotifications();
      } else if (name === 'location') {
        await NexusPermissions.requestLocation();
      } else if (name === 'files') {
        document.getElementById('file-input').click();
      }
    } catch (err) {
      NexusAnimations.toast(`${LABELS[name]} access was denied or unavailable.`);
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    NexusCore.bus.on('nexus:ready', render);
    NexusCore.bus.on('permissions:changed', render);
  });
})();
