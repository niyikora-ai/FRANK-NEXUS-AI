/**
 * components/assistant-extras.js
 * -----------------------------------------------------------------------
 * Closes out the remaining Phase 3 surface area on top of the existing
 * modules — no new module dependencies, just wiring into NexusCommands,
 * NexusMemory, NexusPermissions and NexusAnimations:
 *
 *   - Weather panel (Open-Meteo, no API key required, gated on location
 *     permission the user explicitly grants)
 *   - Security Center panel (permission summary + an honest, purely
 *     client-side "security scan" — see computeSecurityScore() for
 *     exactly what it checks and why)
 *   - Memory Summary panel
 *   - Recent Commands panel
 *   - Tasks panel (add / complete / delete)
 *   - The remaining voice+text commands: show reminders, add/complete/
 *     delete task, show weather, dark/light mode, voice mode on/off,
 *     security scan, save/recall/clear memory, import data, help,
 *     explain this, summarize, continue last task
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  /* ============================= WEATHER ============================= */

  const WEATHER_CODES = {
    0: 'Clear sky', 1: 'Mostly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing rime fog',
    51: 'Light drizzle', 53: 'Drizzle', 55: 'Dense drizzle',
    61: 'Light rain', 63: 'Rain', 65: 'Heavy rain',
    71: 'Light snow', 73: 'Snow', 75: 'Heavy snow',
    80: 'Rain showers', 81: 'Rain showers', 82: 'Violent rain showers',
    95: 'Thunderstorm', 96: 'Thunderstorm w/ hail', 99: 'Severe thunderstorm w/ hail',
  };

  function setWeatherPanel(html) {
    const el = document.getElementById('weather-body');
    if (el) el.innerHTML = html;
  }

  async function showWeather() {
    setWeatherPanel('<div class="empty-hint">Requesting location…</div>');
    let pos;
    try {
      pos = await NexusPermissions.requestLocation();
    } catch (err) {
      setWeatherPanel('<div class="empty-hint">Location permission denied — weather needs it to know where you are.</div>');
      NexusAnimations.toast('Location permission was denied.');
      return;
    }

    const { latitude, longitude } = pos.coords;
    setWeatherPanel('<div class="empty-hint">Fetching current conditions…</div>');
    try {
      const res = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`
      );
      const data = await res.json();
      const cw = data.current_weather;
      const desc = WEATHER_CODES[cw.weathercode] || 'Conditions unavailable';
      setWeatherPanel(`
        <ul class="clean">
          <li>Temperature <span class="tag">${cw.temperature}°C</span></li>
          <li>Wind <span class="tag">${cw.windspeed} km/h</span></li>
          <li>Conditions <span class="tag">${desc}</span></li>
        </ul>
      `);
      NexusAnimations.toast('Weather updated.');
    } catch (err) {
      setWeatherPanel('<div class="empty-hint">Could not reach the weather service — check your connection.</div>');
    }
  }

  /* ========================= SECURITY CENTER ========================= */

  function computeSecurityScore() {
    const perms = NexusPermissions.getAll();
    const grantedCount = Object.values(perms).filter((s) => s === 'granted').length;
    const totalPerms = Object.keys(perms).length;

    // Honest, transparent scoring — every factor here is something we can
    // actually observe from the browser, nothing simulated:
    //   +40 for running in a secure context (HTTPS or localhost)
    //   +40 spread across granted-vs-total permissions (proportional)
    //   +20 for having an access code configured
    const secureCtxPoints = window.isSecureContext ? 40 : 0;
    const permPoints = totalPerms ? Math.round((grantedCount / totalPerms) * 40) : 0;
    const authPoints = NexusAuth.hasCode() ? 20 : 0;
    const score = secureCtxPoints + permPoints + authPoints;

    return { score, secureCtx: window.isSecureContext, grantedCount, totalPerms, hasCode: NexusAuth.hasCode() };
  }

  function renderSecurityCenter() {
    const el = document.getElementById('security-body');
    if (!el) return;
    const { score, secureCtx, grantedCount, totalPerms, hasCode } = computeSecurityScore();
    const lastScan = NexusMemory.raw.read('lastSecurityScan', null);

    el.innerHTML = `
      <div class="bar-row">
        <span class="label">Security Score</span>
        <div class="bar-track"><div class="bar-fill" style="width:${score}%"></div></div>
        <span class="bar-val">${score}</span>
      </div>
      <ul class="clean">
        <li>Secure Context <span class="tag">${secureCtx ? 'Yes (HTTPS/localhost)' : 'No'}</span></li>
        <li>Permissions Granted <span class="tag">${grantedCount} / ${totalPerms}</span></li>
        <li>Access Code Set <span class="tag">${hasCode ? 'Yes' : 'No'}</span></li>
        <li>Last Scan <span class="tag">${lastScan ? new Date(lastScan).toLocaleTimeString() : 'Never'}</span></li>
      </ul>
    `;
  }

  function runSecurityScan() {
    NexusMemory.raw.write('lastSecurityScan', new Date().toISOString());
    renderSecurityCenter();
    const { score } = computeSecurityScore();
    NexusAnimations.toast(`Security scan complete — score ${score}/100.`);
  }

  /* ========================= MEMORY SUMMARY ========================= */

  function renderMemorySummary() {
    const el = document.getElementById('memory-summary-body');
    if (!el) return;
    const notes = NexusMemory.notes.all();
    const reminders = NexusMemory.reminders.all();
    const tasks = NexusMemory.tasks.all();
    const doneTasks = tasks.filter((t) => t.done).length;
    const chat = NexusMemory.chatHistory.all();
    const recent = NexusMemory.recentCommands.all();

    el.innerHTML = `
      <ul class="clean">
        <li>Notes <span class="tag">${notes.length}</span></li>
        <li>Reminders <span class="tag">${reminders.length}</span></li>
        <li>Tasks <span class="tag">${doneTasks}/${tasks.length} done</span></li>
        <li>Chat Messages <span class="tag">${chat.length}</span></li>
        <li>Recent Commands <span class="tag">${recent.length}</span></li>
      </ul>
    `;
  }

  /* ======================== RECENT COMMANDS ========================== */

  function renderRecentCommands() {
    const el = document.getElementById('recent-commands-body');
    if (!el) return;
    const list = NexusMemory.recentCommands.all();
    el.innerHTML = list.length
      ? list.slice(0, 8).map((c) => `<li>${c.text} <span class="tag">${new Date(c.at).toLocaleTimeString()}</span></li>`).join('')
      : '<div class="empty-hint">No commands run yet.</div>';
  }

  /* =============================== TASKS ============================== */

  function renderTasks() {
    const el = document.getElementById('tasks-body');
    if (!el) return;
    const tasks = NexusMemory.tasks.all();
    el.innerHTML = tasks.length
      ? tasks
          .slice(0, 8)
          .map(
            (t) => `
        <div class="task-item">
          <span style="${t.done ? 'text-decoration:line-through; color:var(--text-dim);' : ''}">${t.text}</span>
          <span>
            <button class="modal-close" data-toggle-task="${t.id}" title="Toggle done" style="margin-right:4px;">${t.done ? '↺' : '✓'}</button>
            <button class="modal-close" data-delete-task="${t.id}" title="Delete">✕</button>
          </span>
        </div>`
          )
          .join('')
      : '<div class="empty-hint">No tasks yet — try "add task".</div>';

    el.querySelectorAll('[data-toggle-task]').forEach((btn) =>
      btn.addEventListener('click', () => { NexusMemory.tasks.toggle(btn.dataset.toggleTask); })
    );
    el.querySelectorAll('[data-delete-task]').forEach((btn) =>
      btn.addEventListener('click', () => { NexusMemory.tasks.remove(btn.dataset.deleteTask); })
    );
  }

  function findTaskBySubstring(text) {
    const needle = text.toLowerCase().trim();
    if (!needle) return null;
    return NexusMemory.tasks.all().find((t) => t.text.toLowerCase().includes(needle));
  }

  function openChatWithMessage(text) {
    document.getElementById('open-chat-btn').click();
    if (window.NexusChat) {
      // The chat panel owns rendering; simplest integration point is to
      // push straight into its input + send, reusing its own pipeline.
      const input = document.getElementById('chat-input');
      input.value = text;
      document.getElementById('chat-send').click();
    }
  }

  /* ========================== BOOT / WIRING =========================== */

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('weather-refresh').addEventListener('click', () => NexusCommands.parseAndRun('show weather'));
    document.getElementById('security-scan-btn').addEventListener('click', () => NexusCommands.parseAndRun('run security scan'));
    document.getElementById('tasks-add-btn').addEventListener('click', () => {
      const text = prompt('New task:');
      if (text && text.trim()) NexusCommands.parseAndRun(`add task ${text.trim()}`);
    });

    NexusCore.bus.on('nexus:ready', () => {
      renderTasks();
      renderMemorySummary();
      renderRecentCommands();
      renderSecurityCenter();

      NexusCore.bus.on('memory:tasks-changed', renderTasks);
      NexusCore.bus.on('memory:tasks-changed', renderMemorySummary);
      NexusCore.bus.on('memory:notes-changed', renderMemorySummary);
      NexusCore.bus.on('memory:reminders-changed', renderMemorySummary);
      NexusCore.bus.on('memory:commands-changed', renderRecentCommands);
      NexusCore.bus.on('memory:reset', () => {
        renderTasks(); renderMemorySummary(); renderRecentCommands(); renderSecurityCenter();
      });
      NexusCore.bus.on('permissions:changed', renderSecurityCenter);

      NexusCommands.register('show-weather', ['show weather', "what's the weather", 'weather'], showWeather, 'Show Weather');

      NexusCommands.register('security-scan', ['run security scan', 'security scan', 'scan system'], runSecurityScan, 'Run Security Scan');

      NexusCommands.register('show-reminders', ['show reminders', 'my reminders', 'list reminders'], () => {
        document.getElementById('system-status-panel').scrollIntoView({ behavior: 'smooth', block: 'center' });
        const list = NexusMemory.reminders.all();
        NexusAnimations.toast(list.length ? `You have ${list.length} reminder(s).` : 'No reminders yet.');
      }, 'Show Reminders');

      NexusCommands.register('add-task', ['add task', 'new task', 'create task'], (text) => {
        const content = text.replace(/^(add task|new task|create task)/i, '').trim() || text;
        NexusMemory.tasks.add(content);
        NexusAnimations.toast('Task added.');
      }, 'Add Task');

      NexusCommands.register('complete-task', ['complete task', 'finish task', 'mark task done'], (text) => {
        const content = text.replace(/^(complete task|finish task|mark task done)/i, '').trim();
        const match = findTaskBySubstring(content);
        if (match) { NexusMemory.tasks.toggle(match.id); NexusAnimations.toast(`Marked "${match.text}" complete.`); }
        else NexusAnimations.toast('Could not find a matching task.');
      }, 'Complete Task');

      NexusCommands.register('delete-task', ['delete task', 'remove task'], (text) => {
        const content = text.replace(/^(delete task|remove task)/i, '').trim();
        const match = findTaskBySubstring(content);
        if (match) { NexusMemory.tasks.remove(match.id); NexusAnimations.toast(`Deleted "${match.text}".`); }
        else NexusAnimations.toast('Could not find a matching task.');
      }, 'Delete Task');

      NexusCommands.register('dark-mode-on', ['turn on dark mode', 'dark mode', 'enable dark mode'], () => {
        NexusSettings.update({ theme: 'dark' });
        NexusAnimations.toast('Dark mode enabled.');
      }, 'Turn On Dark Mode');
      NexusCommands.register('light-mode-on', ['turn off dark mode', 'light mode', 'disable dark mode'], () => {
        NexusSettings.update({ theme: 'light' });
        NexusAnimations.toast('Light mode enabled.');
      }, 'Turn Off Dark Mode');

      NexusCommands.register('enable-voice-mode', ['enable voice mode', 'turn on voice mode', 'wake mode on'], () => {
        NexusVoice.setWakeMode(true);
        NexusSettings.update({ voiceModeEnabled: true });
        document.getElementById('wake-mode-toggle').checked = true;
        NexusAnimations.toast('Voice wake mode enabled.');
      }, 'Enable Voice Mode');
      NexusCommands.register('disable-voice-mode', ['disable voice mode', 'turn off voice mode', 'wake mode off'], () => {
        NexusVoice.setWakeMode(false);
        NexusSettings.update({ voiceModeEnabled: false });
        document.getElementById('wake-mode-toggle').checked = false;
        NexusAnimations.toast('Voice wake mode disabled.');
      }, 'Disable Voice Mode');

      NexusCommands.register('save-memory', ['save memory', 'export data', 'export memory'], () => {
        NexusSettings.exportSettingsFile();
        NexusAnimations.toast('Memory exported to a file.');
      }, 'Save Memory');

      NexusCommands.register('recall-memory', ['recall memory', 'memory summary', 'what do you remember'], () => {
        renderMemorySummary();
        document.getElementById('memory-summary-panel').scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 'Recall Memory');

      NexusCommands.register('clear-memory', ['clear memory', 'reset memory', 'forget everything'], () => {
        if (confirm('Clear all FRANK NEXUS memory on this device? This cannot be undone.')) {
          NexusSettings.resetAll();
          NexusAnimations.toast('Memory cleared.');
        }
      }, 'Clear Memory');

      NexusCommands.register('import-data', ['import data', 'import memory', 'import settings'], () => {
        document.getElementById('setting-import-input').click();
      }, 'Import Data');

      NexusCommands.register('help-me', ['help me', 'help', 'what can you do'], () => openChatWithMessage('help'), 'Help');

      NexusCommands.register('explain-this', ['explain this', 'explain that'], () => {
        const history = NexusMemory.chatHistory.all();
        const lastUser = [...history].reverse().find((m) => m.role === 'user');
        openChatWithMessage(lastUser ? `Can you explain this in more detail: ${lastUser.text}` : 'explain this');
      }, 'Explain This');

      NexusCommands.register('summarize', ['summarize', 'give me a summary'], () => {
        const tasks = NexusMemory.tasks.all();
        const notes = NexusMemory.notes.all();
        const reminders = NexusMemory.reminders.all();
        const summary = `You have ${tasks.filter((t) => !t.done).length} open task(s), ${reminders.length} reminder(s), and ${notes.length} note(s) saved.`;
        openChatWithMessage(summary);
      }, 'Summarize');

      NexusCommands.register('continue-last-task', ['continue last task', 'continue', 'resume'], () => {
        const last = NexusMemory.lastTask.get();
        if (last && last.text) {
          NexusAnimations.toast(`Continuing: ${last.text}`);
          NexusCommands.parseAndRun(last.text);
        } else {
          NexusAnimations.toast('No previous task to continue.');
        }
      }, 'Continue Last Task');
    });
  });
})();
