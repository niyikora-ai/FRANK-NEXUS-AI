/**
 * components/quick-panels.js
 * -----------------------------------------------------------------------
 * Makes the Quick Access buttons functional, and implements the small
 * self-contained panels behind them: Camera, File picker, Calculator,
 * Calendar, plus command handlers for reminders/notes/web search/system
 * status that don't need their own modal.
 *
 * Every command is registered with NexusCommands.register() so the exact
 * same logic runs whether the user clicks a button or says the command
 * out loud to FRANK.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  function openModal(id) {
    document.getElementById(id).classList.add('open');
  }
  function closeModal(id) {
    document.getElementById(id).classList.remove('open');
  }

  /* ---------------- Camera ---------------- */
  let cameraStream = null;
  async function openCamera() {
    openModal('camera-modal');
    NexusMemory.raw.write('lastOpenPanel', 'camera');
    const video = document.getElementById('camera-video');
    try {
      cameraStream = await NexusPermissions.requestCamera();
      video.srcObject = cameraStream;
    } catch (err) {
      document.querySelector('.camera-hint').textContent =
        'Camera access was denied, or this page is not running in a secure context (camera requires HTTPS or localhost).';
    }
  }
  function closeCamera() {
    if (cameraStream) {
      cameraStream.getTracks().forEach((t) => t.stop());
      cameraStream = null;
    }
    closeModal('camera-modal');
  }

  /* ---------------- Files ---------------- */
  function openFiles() {
    document.getElementById('file-input').click();
  }
  function handleFileChosen(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    NexusPermissions.markFilesGranted();
    NexusAnimations.toast(`Selected: ${files.map((f) => f.name).join(', ')}`);
  }

  /* ---------------- Calculator ---------------- */
  let calcExpr = '';
  function calcPress(key) {
    const display = document.getElementById('calc-display');
    if (key === 'C') {
      calcExpr = '';
    } else if (key === '=') {
      try {
        // Restrict to digits/operators only before evaluating.
        if (!/^[0-9+\-*/.()\s]+$/.test(calcExpr)) throw new Error('invalid');
        calcExpr = String(Function(`"use strict"; return (${calcExpr || 0})`)());
      } catch (err) {
        calcExpr = 'Error';
      }
    } else {
      calcExpr = calcExpr === 'Error' ? key : calcExpr + key;
    }
    display.textContent = calcExpr || '0';
  }

  /* ---------------- Calendar ---------------- */
  function renderCalendar() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const first = new Date(year, month, 1);
    const startDow = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    document.getElementById('cal-month-label').textContent =
      now.toLocaleDateString([], { month: 'long', year: 'numeric' });

    const grid = document.getElementById('cal-grid');
    const dows = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    let html = dows.map((d) => `<div class="dow">${d}</div>`).join('');
    for (let i = 0; i < startDow; i++) html += `<div class="cal-day blank"></div>`;
    for (let d = 1; d <= daysInMonth; d++) {
      const isToday = d === now.getDate();
      html += `<div class="cal-day${isToday ? ' today' : ''}">${d}</div>`;
    }
    grid.innerHTML = html;
  }

  /* ---------------- Reminders / Notes / Web search / System status ---------------- */
  function renderReminders() {
    const list = NexusMemory.reminders.all();
    const el = document.getElementById('reminders-list');
    if (!el) return;
    el.innerHTML = list.length
      ? list.slice(0, 6).map((r) => `<li>${r.text}${r.when ? ` <span class="tag">${r.when}</span>` : ''}</li>`).join('')
      : '<div class="empty-hint">No reminders yet — try "create reminder".</div>';
  }

  function renderNotes() {
    const list = NexusMemory.notes.all();
    const el = document.getElementById('notes-list');
    if (!el) return;
    el.innerHTML = list.length
      ? list.slice(0, 6).map((n) => `<li>${n.text}</li>`).join('')
      : '<div class="empty-hint">No notes yet — try "save note".</div>';
  }

  function updateLiveStatus() {
    const { time, date } = NexusLiveData.now();
    const battery = NexusLiveData.battery();
    const network = NexusLiveData.network();
    const device = NexusLiveData.device();

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('live-time', time);
    set('live-date', date);
    set('live-network', `${network.online ? 'Online' : 'Offline'} · ${network.type}`);
    set('live-battery-val', battery ? `${battery.level}%${battery.charging ? ' ⚡' : ''}` : 'N/A');
    const batteryBar = document.getElementById('live-battery-bar');
    if (batteryBar) batteryBar.style.width = battery ? `${battery.level}%` : '0%';
    set('live-device', device.cores ? `${device.cores} cores${device.memoryGB ? ` · ${device.memoryGB}GB` : ''}` : 'Unavailable');
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('camera-close').addEventListener('click', closeCamera);
    document.getElementById('file-input').addEventListener('change', handleFileChosen);
    document.querySelectorAll('.calc-key').forEach((btn) =>
      btn.addEventListener('click', () => calcPress(btn.dataset.key))
    );
    document.getElementById('calculator-close').addEventListener('click', () => closeModal('calculator-modal'));
    document.getElementById('calendar-close').addEventListener('click', () => closeModal('calendar-modal'));

    document.querySelectorAll('[data-quick]').forEach((btn) => {
      btn.addEventListener('click', () => NexusCommands.parseAndRun(btn.dataset.quick));
    });

    NexusCore.bus.on('nexus:ready', () => {
      renderReminders();
      renderNotes();
      updateLiveStatus();
      setInterval(updateLiveStatus, 15000);

      NexusCommands.register('open-camera', ['open camera', 'camera'], openCamera, 'Open Camera');
      NexusCommands.register('open-files', ['open files', 'files'], openFiles, 'Open Files');
      NexusCommands.register('open-calculator', ['open calculator', 'calculator', 'calculate'], () => {
        calcExpr = '';
        document.getElementById('calc-display').textContent = '0';
        openModal('calculator-modal');
        NexusMemory.raw.write('lastOpenPanel', 'calculator');
      }, 'Open Calculator');
      NexusCommands.register('show-calendar', ['show calendar', 'calendar'], () => {
        renderCalendar();
        openModal('calendar-modal');
        NexusMemory.raw.write('lastOpenPanel', 'calendar');
      }, 'Show Calendar');
      NexusCommands.register('web-search', ['search the web', 'search for', 'web search'], (text) => {
        const query = text.replace(/^(search the web for|search for|web search|search)/i, '').trim() || text;
        window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank', 'noopener');
      }, 'Search the Web');
      NexusCommands.register('create-reminder', ['create reminder', 'set reminder', 'remind me'], (text) => {
        const content = text.replace(/^(create reminder|set reminder|remind me to|remind me)/i, '').trim() || text;
        NexusMemory.reminders.add(content);
        renderReminders();
        NexusAnimations.toast('Reminder saved.');
      }, 'Create Reminder');
      NexusCommands.register('save-note', ['save note', 'take a note', 'note that'], (text) => {
        const content = text.replace(/^(save note|take a note|note that)/i, '').trim() || text;
        NexusMemory.notes.add(content);
        renderNotes();
        NexusAnimations.toast('Note saved.');
      }, 'Save Note');
      NexusCommands.register('system-status', ['system status', 'show status'], () => {
        updateLiveStatus();
        document.getElementById('system-status-panel').scrollIntoView({ behavior: 'smooth', block: 'center' });
        NexusAnimations.toast('Here is the current system status.');
      }, 'Show System Status');

      NexusCore.bus.on('memory:reminders-changed', renderReminders);
      NexusCore.bus.on('memory:notes-changed', renderNotes);
    });
  });
})();
