/**
 * components/settings-panel.js
 * -----------------------------------------------------------------------
 * Renders and wires the Settings modal. Reads/writes exclusively through
 * NexusSettings so the persistence details stay in settings.js.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  function populateVoiceSelect() {
    const select = document.getElementById('setting-voice');
    if (!select) return;
    const voices = NexusSettings.getVoices();
    const prefs = NexusSettings.get();
    select.innerHTML = '<option value="">System default</option>' +
      voices.map((v) => `<option value="${v.voiceURI}">${v.name} (${v.lang})</option>`).join('');
    select.value = prefs.voiceURI || '';
  }

  function syncControlsFromPrefs() {
    const prefs = NexusSettings.get();
    document.getElementById('setting-dark-mode').checked = prefs.theme !== 'light';
    document.getElementById('setting-sound').checked = !!prefs.soundEffects;
    document.getElementById('setting-language').value = prefs.language || 'en';
    document.getElementById('setting-animation').value = prefs.animationQuality || 'high';
    document.getElementById('setting-assistant-name').value = prefs.assistantName || 'FRANK';
    populateVoiceSelect();
  }

  document.addEventListener('DOMContentLoaded', () => {
    const openBtn = document.getElementById('open-settings-btn');
    const closeBtn = document.getElementById('settings-close');

    openBtn.addEventListener('click', () => {
      syncControlsFromPrefs();
      document.getElementById('settings-modal').classList.add('open');
      NexusMemory.raw.write('lastOpenPanel', 'settings');
    });
    closeBtn.addEventListener('click', () => document.getElementById('settings-modal').classList.remove('open'));

    NexusCore.bus.on('nexus:ready', () => {
      NexusCommands.register('open-settings', ['open settings', 'settings'], () => openBtn.click(), 'Open Settings');
    });

    document.getElementById('setting-dark-mode').addEventListener('change', (e) => {
      NexusSettings.update({ theme: e.target.checked ? 'dark' : 'light' });
    });
    document.getElementById('setting-sound').addEventListener('change', (e) => {
      NexusSettings.update({ soundEffects: e.target.checked });
      if (e.target.checked) NexusSettings.playSoundEffect('confirm');
    });
    document.getElementById('setting-language').addEventListener('change', (e) => {
      NexusSettings.update({ language: e.target.value });
    });
    document.getElementById('setting-animation').addEventListener('change', (e) => {
      NexusSettings.update({ animationQuality: e.target.value });
    });
    document.getElementById('setting-voice').addEventListener('change', (e) => {
      NexusSettings.update({ voiceURI: e.target.value });
    });
    document.getElementById('setting-assistant-name').addEventListener('change', (e) => {
      NexusSettings.update({ assistantName: e.target.value });
      NexusAnimations.toast(`Assistant switched to ${e.target.value}.`);
    });

    document.getElementById('setting-export').addEventListener('click', () => {
      NexusSettings.exportSettingsFile();
      NexusAnimations.toast('Settings exported.');
    });
    document.getElementById('setting-import-input').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        await NexusSettings.importSettingsFile(file);
        syncControlsFromPrefs();
        NexusAnimations.toast('Settings imported.');
      } catch (err) {
        NexusAnimations.toast('Import failed — file was not valid settings JSON.');
      }
    });
    document.getElementById('setting-reset').addEventListener('click', () => {
      if (confirm('Reset all FRANK NEXUS memory on this device? Notes, reminders, chat history and preferences will be cleared. Your access code stays set.')) {
        NexusSettings.resetAll();
        syncControlsFromPrefs();
        NexusAnimations.toast('Memory reset.');
      }
    });

    NexusCore.bus.on('settings:voices-loaded', populateVoiceSelect);
  });
})();
