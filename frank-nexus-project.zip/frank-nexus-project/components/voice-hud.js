/**
 * components/voice-hud.js
 * -----------------------------------------------------------------------
 * Wires the floating mic button + transcript panel to NexusVoice, and
 * feeds recognized speech into NexusCommands. Also drives the arc-reactor
 * listening/speaking animation via NexusAnimations.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  function assistantName() {
    return NexusSettings.get().assistantName || 'FRANK';
  }

  function setTranscript(who, text) {
    const el = document.getElementById('voice-transcript');
    if (!el) return;
    el.innerHTML = `<span class="who">${who}:</span> ${text}`;
  }

  function syncAssistantNameUI() {
    const name = assistantName();
    const titleEl = document.querySelector('.core-title');
    if (titleEl) titleEl.textContent = name;
    const badgeEl = document.getElementById('assistant-badge');
    if (badgeEl) badgeEl.textContent = `● Active: ${name}`;
    const wakeLabel = document.getElementById('wake-phrase-label');
    if (wakeLabel) wakeLabel.textContent = `Wake phrase "Hey ${name}"`;
  }

  function respondTo(commandText) {
    const result = NexusCommands.parseAndRun(commandText);
    const reply = result.matched
      ? `Done — running "${result.id.replace(/-/g, ' ')}."`
      : `I heard "${commandText}", but I don't have a command set up for that yet.`;
    setTranscript(assistantName(), reply);
    NexusVoice.speak(reply);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const fab = document.getElementById('mic-fab');
    const wakeToggle = document.getElementById('wake-mode-toggle');

    NexusCore.bus.on('nexus:ready', () => {
      syncAssistantNameUI();
      if (wakeToggle) wakeToggle.checked = !!NexusSettings.get().voiceModeEnabled;
      if (NexusSettings.get().voiceModeEnabled) NexusVoice.setWakeMode(true);

      if (!NexusVoice.isSupported()) {
        fab.classList.add('unsupported');
        fab.title = 'Voice recognition is not supported in this browser.';
        if (wakeToggle) wakeToggle.disabled = true;
      }
    });
    NexusCore.bus.on('memory:preferences-changed', syncAssistantNameUI);

    fab.addEventListener('click', () => {
      if (!NexusVoice.isSupported()) {
        NexusAnimations.toast('Voice recognition is not supported in this browser.');
        return;
      }
      NexusVoice.startPushToTalk();
    });

    if (wakeToggle) {
      wakeToggle.addEventListener('change', (e) => {
        NexusVoice.setWakeMode(e.target.checked);
        NexusSettings.update({ voiceModeEnabled: e.target.checked });
        NexusAnimations.toast(e.target.checked ? `Wake phrase "Hey ${assistantName()}" enabled.` : 'Wake phrase disabled.');
      });
    }

    NexusCore.bus.on('voice:listening-start', () => {
      fab.classList.add('listening');
      NexusAnimations.setListening(true);
      NexusSettings.playSoundEffect('listen');
      setTranscript('You', '…listening');
    });
    NexusCore.bus.on('voice:listening-end', () => {
      fab.classList.remove('listening');
      NexusAnimations.setListening(false);
    });
    NexusCore.bus.on('voice:interim', (text) => setTranscript('You', text));
    NexusCore.bus.on('voice:final', (text) => setTranscript('You', text));
    NexusCore.bus.on('voice:command', (text) => respondTo(text));
    NexusCore.bus.on('voice:error', (err) => {
      if (err === 'no-speech') return; // benign — user just didn't say anything
      NexusAnimations.toast(`Voice error: ${err}`);
    });
    NexusCore.bus.on('voice:speaking-start', () => NexusAnimations.setSpeaking(true));
    NexusCore.bus.on('voice:speaking-end', () => NexusAnimations.setSpeaking(false));
  });
})();
