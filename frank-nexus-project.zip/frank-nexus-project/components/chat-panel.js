/**
 * components/chat-panel.js
 * -----------------------------------------------------------------------
 * The AI Chat panel. Designed so a real model API can be plugged in
 * later without touching any UI code:
 *
 *   NexusChat.setResponder(async (message, history) => "reply text")
 *
 * By default `defaultResponder` below is used, which only echoes back a
 * local, canned acknowledgement — there is no AI API connected in this
 * build. Swap it out (e.g. with a fetch() to your own backend that calls
 * the Anthropic API — never call a model API with a secret key directly
 * from client-side code) and the whole chat UI, history, and formatting
 * keep working unchanged.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  /** Very small, safe markdown-ish formatter: escapes HTML first, then
   *  re-introduces **bold**, `inline code`, and ```code blocks```. */
  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function formatMessage(text) {
    let html = escapeHtml(text);
    html = html.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\n/g, '<br>');
    return html;
  }

  async function defaultResponder(message) {
    // No AI API is connected in this build. A few common phrases get a
    // real, locally-generated answer (no model call involved) since the
    // Command Engine already has the data to answer them honestly;
    // everything else keeps the generic "not connected yet" message.
    await new Promise((r) => setTimeout(r, 350));

    const lower = message.toLowerCase().trim();
    if (/^(help|help me|what can you do)/.test(lower)) {
      return (
        '**Things you can say or type:**\n' +
        '`open camera` · `open files` · `open calculator` · `show calendar` · `open settings`\n' +
        '`search the web for <topic>` · `show weather` · `show reminders` · `remind me to <thing>`\n' +
        '`add task <thing>` · `complete task <thing>` · `delete task <thing>` · `save note <thing>`\n' +
        '`system status` · `run security scan` · `save memory` · `clear memory` · `continue last task`'
      );
    }

    return (
      `I heard: "${message}"\n\n` +
      `No AI model is connected yet in this build — this panel is wired ` +
      `and ready for one. Try a device command instead, like `
      + '`open camera`' + `, ` + '`show calendar`' + `, or ` + '`save note buy milk`' + `.`
    );
  }

  let responder = defaultResponder;
  let history = [];

  const NexusChat = {
    setResponder(fn) {
      responder = fn;
    },
  };
  window.NexusChat = NexusChat;

  function appendMessage(role, text, { typing = false } = {}) {
    const log = document.getElementById('chat-log');
    const div = document.createElement('div');
    div.className = `msg ${role}${typing ? ' typing' : ''}`;
    div.innerHTML = formatMessage(text);
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    return div;
  }

  function renderHistory() {
    history = NexusMemory.chatHistory.all();
    const log = document.getElementById('chat-log');
    log.innerHTML = '';
    if (!history.length) {
      appendMessage('assistant', 'Hi, I\'m FRANK. Ask me something, or try a command like **open calculator**.');
    } else {
      history.forEach((m) => appendMessage(m.role, m.text));
    }
  }

  async function sendMessage(text) {
    const trimmed = (text || '').trim();
    if (!trimmed) return;
    appendMessage('user', trimmed);
    NexusMemory.chatHistory.add('user', trimmed);

    const typingEl = appendMessage('assistant', '', { typing: true });
    NexusAnimations.setThinking(true);
    try {
      const reply = await responder(trimmed, NexusMemory.chatHistory.all());
      typingEl.classList.remove('typing');
      typingEl.innerHTML = formatMessage(reply);
      NexusMemory.chatHistory.add('assistant', reply);
    } catch (err) {
      typingEl.classList.remove('typing');
      typingEl.innerHTML = formatMessage('Sorry — something went wrong generating a reply.');
    } finally {
      NexusAnimations.setThinking(false);
    }
    document.getElementById('chat-log').scrollTop = document.getElementById('chat-log').scrollHeight;
  }

  document.addEventListener('DOMContentLoaded', () => {
    const openBtn = document.getElementById('open-chat-btn');
    const closeBtn = document.getElementById('chat-close');
    const input = document.getElementById('chat-input');
    const sendBtn = document.getElementById('chat-send');
    const micBtn = document.getElementById('chat-mic');

    function openChat() {
      renderHistory();
      document.getElementById('chat-modal').classList.add('open');
      NexusMemory.raw.write('lastOpenPanel', 'chat');
      input.focus();
    }

    openBtn.addEventListener('click', openChat);
    closeBtn.addEventListener('click', () => document.getElementById('chat-modal').classList.remove('open'));
    sendBtn.addEventListener('click', () => { sendMessage(input.value); input.value = ''; });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { sendMessage(input.value); input.value = ''; }
    });
    micBtn.addEventListener('click', () => {
      if (!NexusVoice.isSupported()) {
        NexusAnimations.toast('Voice recognition is not supported in this browser.');
        return;
      }
      const off = NexusCore.bus.on('voice:final', (text) => {
        input.value = text;
        off();
      });
      NexusVoice.startPushToTalk();
    });

    NexusCore.bus.on('nexus:ready', () => {
      NexusCommands.register('open-ai-chat', ['open ai chat', 'open chat', 'ai chat'], openChat, 'Open AI Chat');
    });
  });
})();
