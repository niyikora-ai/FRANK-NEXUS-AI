# FRANK NEXUS AI — Phase 2

A modular, permission-based, privacy-first personal assistant dashboard.
Keeps the Phase 1 Iron Man–inspired red/gold HUD and arc-reactor visual
identity; everything else is now real, working functionality instead of
demo values.

## Running it

Voice recognition, camera/microphone access, and the `fetch()` call that
loads `data/commands.json` all require a **secure context** and, in most
browsers, will not work correctly opened directly as a `file://` path.
Serve the folder over local HTTP instead:

```bash
cd frank-nexus-project
python3 -m http.server 8080
# then open http://localhost:8080 in your browser
```

Any static server works (`npx serve`, VS Code's Live Server extension,
etc.) — `localhost` counts as a secure context even without HTTPS.

## First run

There's no hard-coded password. The first time you open the app you'll
be asked to **create your own access code** — it's hashed (SHA-256 +
random salt) and stored only in this browser's `localStorage`. Nothing
is transmitted anywhere. See `js/modules/auth.js` for exactly how, and
for where to plug in a real backend login later.

## Folder structure

```
index.html              Shell markup: lock screen, dashboard, modals
css/
  base.css              Design tokens, resets, lock screen, dashboard shell
  components.css        Panel-specific styles (core hero, chat, modals, etc.)
js/
  app.js                Lock/unlock flow, boots NexusCore
  modules/
    nexus-core.js       Event bus + module registry + boot sequence
    memory.js           localStorage-backed persistence (notes, reminders, etc.)
    auth.js             Hashed local passcode (swap in a backend later)
    permissions.js      Camera / mic / notifications / location / files
    settings.js         Preferences, theme, TTS voice list, export/import
    animations.js       Listening/speaking state, toasts, rAF helper
    voice.js            Speech-to-text (push-to-talk + wake phrase) & TTS
    command-engine.js   Keyword-matching command router
    live-data.js        Real time/date/battery/network/device info
components/
  permission-panel.js   Permission Center UI
  voice-hud.js          Mic button + transcript + wake-mode toggle + assistant badge
  quick-panels.js       Camera/Files/Calculator/Calendar + reminder/note/search commands
  settings-panel.js     Settings modal UI (incl. FRANK/KEVINE switch)
  chat-panel.js         AI Chat UI (no model connected yet — see below)
  assistant-extras.js   Weather, Security Center, Memory Summary, Recent Commands,
                        Tasks panels, and the remaining voice/text commands
data/
  commands.json         Data-driven starter command list (28 commands)
assets/, icons/         Reserved for future images/icons
```

## Connecting a real AI model to the chat panel

`components/chat-panel.js` exposes:

```js
NexusChat.setResponder(async (message, history) => {
  // call your own backend here, which in turn calls the model API.
  // Never put a model API key in client-side code.
  return "reply text";
});
```

Call that once (e.g. from a new `components/ai-connector.js`) and the
chat UI, history, and markdown/code formatting all keep working
unchanged.

## Adding a new voice/text command

```js
NexusCommands.register(
  'my-command-id',
  ['phrase one', 'phrase two'],   // patterns to match in free text
  (matchedText) => { /* do the thing */ },
  'Human-readable label'
);
```

Say or type any of the patterns and it routes to the handler — no other
file needs to change.

## Known limitations (by design)

- **Auth is still client-side.** Hashing removes the hard-coded secret,
  but any check running entirely in the browser can be inspected on a
  device someone already controls. Real multi-user security needs a
  backend — `auth.js` is structured so that's a drop-in swap.
- **Wake-phrase listening** only runs while explicitly toggled on, and
  only while the tab is open — browsers don't allow a page to listen
  in the background indefinitely, by design.
- **Battery/device APIs** aren't available in every browser; the UI
  shows "N/A" gracefully rather than guessing.
- **Kinyarwanda** speech-recognition depends entirely on whether the
  visiting browser/OS ships that language pack — this app requests it,
  but can't add support the platform doesn't have.
- **Weather** uses [Open-Meteo](https://open-meteo.com) (no API key
  required) and only runs after the user grants location access.
- **Security Center score** is a transparent, purely client-side check
  (secure context + permissions granted + access code present) — it is
  not a real vulnerability scanner, and the code says so.
