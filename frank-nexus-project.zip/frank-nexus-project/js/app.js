/**
 * app.js
 * -----------------------------------------------------------------------
 * Entry point. Handles the lock screen (first-run "set a code" flow vs.
 * returning "enter your code" flow) and, once unlocked, calls
 * NexusCore.init() to boot every module in order and reveal the
 * dashboard. All panel-specific wiring lives in components/*.js, which
 * listen for the 'nexus:ready' event fired at the end of boot.
 * -----------------------------------------------------------------------
 */
(function () {
  'use strict';

  const lock = document.getElementById('lock');
  const dash = document.getElementById('dash');
  const form = document.getElementById('lock-form');
  const pwInput = document.getElementById('pw');
  const pw2Input = document.getElementById('pw2');
  const pw2Wrap = document.getElementById('pw2-wrap');
  const label = document.getElementById('lock-label-text');
  const hint = document.getElementById('lock-hint-text');
  const submitBtn = document.getElementById('unlock-btn');
  const errorEl = document.getElementById('lock-error');
  const lockCard = document.querySelector('.lock-form');
  const forgotBtn = document.getElementById('forgot-code-btn');

  let mode = 'checking'; // 'setup' | 'unlock'

  function showError(msg) {
    errorEl.textContent = msg;
    errorEl.classList.add('show');
    lockCard.classList.remove('shake');
    void lockCard.offsetWidth;
    lockCard.classList.add('shake');
  }
  function clearError() {
    errorEl.classList.remove('show');
  }

  function renderMode() {
    if (mode === 'setup') {
      label.textContent = 'Create an Access Code';
      hint.textContent = 'This code is hashed and stored only on this device — set anything you\'ll remember.';
      pw2Wrap.style.display = '';
      submitBtn.textContent = 'Create Code & Enter';
      forgotBtn.style.display = 'none';
    } else {
      label.textContent = 'Enter Access Code';
      hint.textContent = '';
      pw2Wrap.style.display = 'none';
      submitBtn.textContent = 'Initialize System';
      forgotBtn.style.display = '';
    }
  }

  async function unlockDashboard() {
    lock.classList.add('hidden');
    dash.classList.add('show');
    await NexusCore.init();
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearError();

    if (mode === 'setup') {
      const a = pwInput.value;
      const b = pw2Input.value;
      if (a.length < 4) return showError('Use at least 4 characters.');
      if (a !== b) return showError('Codes do not match.');
      await NexusAuth.setCode(a);
      await unlockDashboard();
      return;
    }

    const ok = await NexusAuth.verify(pwInput.value);
    if (ok) {
      await unlockDashboard();
    } else {
      showError('ACCESS DENIED — INCORRECT CODE');
      pwInput.value = '';
      pwInput.focus();
    }
  });

  forgotBtn.addEventListener('click', () => {
    if (confirm('Reset your access code? You will need to create a new one. Notes, reminders and settings on this device are kept.')) {
      NexusAuth.clearCode();
      mode = 'setup';
      pwInput.value = '';
      pw2Input.value = '';
      renderMode();
    }
  });

  // NexusAuth/NexusMemory register themselves synchronously when their
  // scripts run, so it's safe to check hasCode() as soon as the DOM is ready.
  document.addEventListener('DOMContentLoaded', async () => {
    await NexusMemory.init();
    mode = NexusAuth.hasCode() ? 'unlock' : 'setup';
    renderMode();
    pwInput.focus();
  });
})();
