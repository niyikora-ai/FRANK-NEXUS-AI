/**
 * auth.js
 * -----------------------------------------------------------------------
 * Replaces the Phase 1 hard-coded password check.
 *
 * IMPORTANT HONESTY NOTE (read this before relying on it):
 * This is still a CLIENT-ONLY authentication scheme. Any check that runs
 * entirely in the browser can, in principle, be inspected or bypassed by
 * someone with access to dev tools on the same device — that is true no
 * matter how the check is implemented. What this module fixes is the
 * specific problem the brief called out: there is no plaintext secret
 * sitting in the source anymore. Instead:
 *
 *   - On first run, the user sets their own access code.
 *   - We generate a random salt, then store only
 *     SHA-256(salt + code) in localStorage — never the code itself.
 *   - Unlocking re-hashes the entered code with the stored salt and
 *     compares digests.
 *
 * For real multi-user or sensitive deployments, swap `verify()` and
 * `setCode()` below for calls to a backend auth endpoint (e.g. POST
 * /api/login returning a session token) — every call site already goes
 * through this module, so no UI code needs to change.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const KEY = 'auth';

  function bufToHex(buf) {
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  async function sha256Hex(text) {
    const data = new TextEncoder().encode(text);
    const digest = await crypto.subtle.digest('SHA-256', data);
    return bufToHex(digest);
  }

  function randomSalt() {
    const arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return bufToHex(arr.buffer);
  }

  const NexusAuth = {
    /** True once a code has been configured on this device. */
    hasCode() {
      return !!NexusMemory.raw.read(KEY, null);
    },

    /**
     * FUTURE-READY HOOK: replace this body with a fetch() to your backend
     * signup/login endpoint. Keep the same async signature.
     */
    async setCode(code) {
      const salt = randomSalt();
      const hash = await sha256Hex(salt + code);
      NexusMemory.raw.write(KEY, { salt, hash });
      return true;
    },

    /**
     * FUTURE-READY HOOK: replace this body with a fetch() call to verify
     * credentials against a backend session, or with WebAuthn/passkey
     * verification. Keep the same async signature (Promise<boolean>).
     */
    async verify(code) {
      const stored = NexusMemory.raw.read(KEY, null);
      if (!stored) return false;
      const hash = await sha256Hex(stored.salt + code);
      return hash === stored.hash;
    },

    /** Used by the "forgot code" flow. Clears the credential only. */
    clearCode() {
      localStorage.removeItem('nexus:' + KEY);
    },
  };

  global.NexusAuth = NexusCore.register('auth', NexusAuth);
})(window);
