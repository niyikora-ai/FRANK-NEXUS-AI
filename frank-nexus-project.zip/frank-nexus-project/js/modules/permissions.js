/**
 * permissions.js
 * -----------------------------------------------------------------------
 * PERMISSION CENTER.
 *
 * This module never bypasses the operating system / browser's own
 * permission prompts — it can only ASK (via the standard Web APIs) and
 * then reflect whatever the user/OS decided back into the UI. There is
 * no way for client-side JS to silently grant itself camera, microphone,
 * location or notification access; that boundary is enforced by the
 * browser and this module respects it fully.
 *
 * Status values used throughout: 'granted' | 'denied' | 'not-requested'.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const STATE_KEY = 'permStatus';
  const defaults = {
    camera: 'not-requested',
    microphone: 'not-requested',
    notifications: 'not-requested',
    location: 'not-requested',
    files: 'not-requested', // files are user-initiated picks, never "denied" by the OS
  };

  let status = Object.assign({}, defaults);

  function persist() {
    NexusMemory.raw.write(STATE_KEY, status);
  }

  function set(name, value) {
    status[name] = value;
    persist();
    NexusCore.bus.emit('permissions:changed', { name, value, status: Object.assign({}, status) });
  }

  const NexusPermissions = {
    async init() {
      status = Object.assign({}, defaults, NexusMemory.raw.read(STATE_KEY, {}));

      // Where the browser exposes the modern Permissions API, sync our
      // recorded state with the real OS-level decision (covers the case
      // where the user changed it from browser settings, not from FRANK).
      if (navigator.permissions && navigator.permissions.query) {
        const map = { camera: 'camera', microphone: 'microphone', notifications: 'notifications', location: 'geolocation' };
        for (const [local, apiName] of Object.entries(map)) {
          try {
            const result = await navigator.permissions.query({ name: apiName });
            status[local] = result.state === 'prompt' ? 'not-requested' : result.state;
            result.onchange = () => set(local, result.state === 'prompt' ? 'not-requested' : result.state);
          } catch (err) {
            // Some browsers don't support querying every permission name — that's fine, ignore.
          }
        }
        persist();
      }
    },

    getAll() {
      return Object.assign({}, status);
    },

    async requestCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        set('camera', 'granted');
        return stream;
      } catch (err) {
        set('camera', 'denied');
        throw err;
      }
    },

    async requestMicrophone() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        set('microphone', 'granted');
        return stream;
      } catch (err) {
        set('microphone', 'denied');
        throw err;
      }
    },

    async requestNotifications() {
      if (!('Notification' in global)) {
        set('notifications', 'denied');
        return 'denied';
      }
      try {
        const result = await Notification.requestPermission();
        set('notifications', result === 'granted' ? 'granted' : 'denied');
        return result;
      } catch (err) {
        set('notifications', 'denied');
        return 'denied';
      }
    },

    requestLocation() {
      return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
          set('location', 'denied');
          reject(new Error('Geolocation not supported'));
          return;
        }
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            set('location', 'granted');
            resolve(pos);
          },
          (err) => {
            set('location', 'denied');
            reject(err);
          }
        );
      });
    },

    /**
     * "File access" has no OS permission prompt of its own in the browser —
     * the user grants access implicitly by picking a file in the native
     * file dialog. We just mark it requested/granted once they do.
     */
    markFilesGranted() {
      set('files', 'granted');
    },
  };

  global.NexusPermissions = NexusCore.register('permissions', NexusPermissions);
})(window);
