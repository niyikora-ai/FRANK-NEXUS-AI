/**
 * voice.js
 * -----------------------------------------------------------------------
 * Wraps the Web Speech API:
 *   - SpeechRecognition (webkitSpeechRecognition in Chrome/Edge/Android)
 *     for speech-to-text, used for both push-to-talk and an optional
 *     "Hey FRANK" wake-phrase mode.
 *   - speechSynthesis for text-to-speech replies.
 *
 * Browser support varies (notably: no SpeechRecognition in Firefox, and
 * it requires a secure context — https or localhost, not file://). This
 * module always checks for support first and reports back through
 * events so the UI can disable the mic button gracefully instead of
 * throwing.
 *
 * Wake-phrase note: true always-on "Hey FRANK" listening the way a
 * dedicated smart speaker does it isn't something a web page can do
 * reliably or politely (it would mean an open mic in a browser tab
 * indefinitely). What we support is continuous recognition *while the
 * user has explicitly turned wake-mode on*, which then listens for the
 * phrase "hey frank" before treating the rest of the utterance as a
 * command. That toggle is off by default.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const SpeechRecognitionImpl = global.SpeechRecognition || global.webkitSpeechRecognition;
  const supported = !!SpeechRecognitionImpl && 'speechSynthesis' in global;

  let recognizer = null;
  let listening = false;
  let wakeMode = false;

  function buildRecognizer(continuous) {
    const rec = new SpeechRecognitionImpl();
    rec.continuous = continuous;
    rec.interimResults = true;
    rec.lang = (NexusMemory.preferences.get().language) || 'en-US';

    rec.onstart = () => {
      listening = true;
      NexusCore.bus.emit('voice:listening-start');
    };
    rec.onend = () => {
      listening = false;
      NexusCore.bus.emit('voice:listening-end');
      if (wakeMode) {
        // Auto-restart continuous recognition for wake-phrase mode.
        try { rec.start(); } catch (err) { /* already starting */ }
      }
    };
    rec.onerror = (e) => {
      NexusCore.bus.emit('voice:error', e.error);
    };
    rec.onresult = (event) => {
      let finalText = '';
      let interimText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += transcript;
        else interimText += transcript;
      }
      if (interimText) NexusCore.bus.emit('voice:interim', interimText);
      if (finalText) {
        const cleaned = finalText.trim();
        NexusCore.bus.emit('voice:final', cleaned);

        if (wakeMode) {
          const wakePhrase = `hey ${(NexusMemory.preferences.get().assistantName || 'FRANK').toLowerCase()}`;
          const lower = cleaned.toLowerCase();
          const idx = lower.indexOf(wakePhrase);
          if (idx !== -1) {
            const command = cleaned.slice(idx + wakePhrase.length).trim();
            if (command) NexusCore.bus.emit('voice:command', command);
          }
        } else {
          NexusCore.bus.emit('voice:command', cleaned);
        }
      }
    };
    return rec;
  }

  const NexusVoice = {
    async init() {
      // Nothing to load from storage besides the language preference,
      // which is read fresh each time a recognizer is built.
    },

    isSupported() {
      return supported;
    },

    isListening() {
      return listening;
    },

    /** Push-to-talk: single utterance, stops automatically on silence. */
    startPushToTalk() {
      if (!supported) {
        NexusCore.bus.emit('voice:error', 'not-supported');
        return;
      }
      if (wakeMode) NexusVoice.setWakeMode(false);
      recognizer = buildRecognizer(false);
      try {
        recognizer.start();
      } catch (err) {
        // start() throws if called while already listening — safe to ignore.
      }
    },

    stop() {
      if (recognizer) {
        try { recognizer.stop(); } catch (err) { /* noop */ }
      }
    },

    /** Toggle continuous "Hey FRANK" wake-phrase listening. */
    setWakeMode(on) {
      wakeMode = on;
      if (!supported) return;
      if (on) {
        recognizer = buildRecognizer(true);
        try { recognizer.start(); } catch (err) { /* noop */ }
      } else if (recognizer) {
        try { recognizer.stop(); } catch (err) { /* noop */ }
      }
    },

    isWakeModeOn() {
      return wakeMode;
    },

    /** Text-to-speech reply. Uses the voice chosen in Settings, if any. */
    speak(text) {
      if (!('speechSynthesis' in global) || !text) return;
      speechSynthesis.cancel(); // don't queue overlapping replies
      const utter = new SpeechSynthesisUtterance(text);
      const prefs = NexusMemory.preferences.get();
      if (prefs.voiceURI) {
        const voice = (NexusSettings.getVoices() || []).find((v) => v.voiceURI === prefs.voiceURI);
        if (voice) utter.voice = voice;
      }
      utter.onstart = () => NexusCore.bus.emit('voice:speaking-start');
      utter.onend = () => NexusCore.bus.emit('voice:speaking-end');
      speechSynthesis.speak(utter);
    },
  };

  global.NexusVoice = NexusCore.register('voice', NexusVoice);
})(window);
