/**
 * settings.js
 * -----------------------------------------------------------------------
 * Reads/writes user preferences (via NexusMemory.preferences) and applies
 * their visible effects: dark/light mode class, animation-quality class,
 * available system voices for text-to-speech, sound effects toggle.
 *
 * UI code (components/settings-panel.js) calls into this module; it never
 * touches localStorage directly.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  let voicesCache = [];

  function applyTheme(prefs) {
    document.body.classList.toggle('light-mode', prefs.theme === 'light');
  }

  function applyAnimationQuality(prefs) {
    document.body.classList.toggle('reduce-motion', prefs.animationQuality === 'low');
  }

  const NexusSettings = {
    async init() {
      const prefs = NexusMemory.preferences.get();
      applyTheme(prefs);
      applyAnimationQuality(prefs);

      // Respect the OS-level reduced-motion preference too, regardless
      // of the in-app setting.
      if (global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.body.classList.add('reduce-motion');
      }

      if ('speechSynthesis' in global) {
        const loadVoices = () => {
          voicesCache = speechSynthesis.getVoices();
          NexusCore.bus.emit('settings:voices-loaded', voicesCache);
        };
        loadVoices();
        speechSynthesis.onvoiceschanged = loadVoices;
      }

      NexusCore.bus.on('memory:preferences-changed', (prefs) => {
        applyTheme(prefs);
        applyAnimationQuality(prefs);
      });
    },

    get() {
      return NexusMemory.preferences.get();
    },

    update(patch) {
      return NexusMemory.preferences.set(patch);
    },

    getVoices() {
      return voicesCache;
    },

    playSoundEffect(kind) {
      const prefs = NexusMemory.preferences.get();
      if (!prefs.soundEffects) return;
      // Lightweight synthesized "beep" via WebAudio so no binary assets
      // are required. kind: 'confirm' | 'error' | 'listen'.
      try {
        const ctx = NexusSettings._audioCtx || (NexusSettings._audioCtx = new (global.AudioContext || global.webkitAudioContext)());
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const freq = kind === 'error' ? 180 : kind === 'listen' ? 720 : 480;
        osc.frequency.value = freq;
        osc.type = 'sine';
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      } catch (err) {
        // Audio isn't essential — fail silently if the browser blocks it
        // before a user gesture has unlocked the AudioContext.
      }
    },

    exportSettingsFile() {
      const dump = NexusMemory.exportAll();
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `frank-nexus-settings-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    },

    async importSettingsFile(file) {
      const text = await file.text();
      const dump = JSON.parse(text);
      NexusMemory.importAll(dump);
      const prefs = NexusMemory.preferences.get();
      applyTheme(prefs);
      applyAnimationQuality(prefs);
      return prefs;
    },

    resetAll() {
      NexusMemory.resetAll(true); // keep the access code so the user isn't locked out
    },
  };

  global.NexusSettings = NexusCore.register('settings', NexusSettings);
})(window);
