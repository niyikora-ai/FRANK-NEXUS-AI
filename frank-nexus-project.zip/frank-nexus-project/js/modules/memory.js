/**
 * memory.js
 * -----------------------------------------------------------------------
 * SMART MEMORY module.
 *
 * Everything here is stored ONLY on the user's device (localStorage).
 * Nothing is sent anywhere. Nothing is written until the user has taken
 * an action that implies consent (setting a preference, saving a note,
 * confirming a reminder, etc.) — FRANK never silently logs behaviour.
 *
 * Storage layout (all keys prefixed "nexus:"):
 *   nexus:preferences   -> { name, theme, language, animationQuality, soundEffects, voiceURI }
 *   nexus:notes         -> [{ id, text, createdAt }]
 *   nexus:reminders     -> [{ id, text, when, createdAt }]
 *   nexus:tasks         -> [{ id, text, done, createdAt }]
 *   nexus:recentCommands-> [{ id, text, at }]      (capped, most recent first)
 *   nexus:chatHistory   -> [{ role, text, at }]
 *   nexus:lastTask      -> { id, text, at } | null (see "continue last task")
 *   nexus:auth          -> { salt, hash }          (see auth.js)
 *
 * If IndexedDB is later needed for larger data sets (e.g. offline
 * document storage), swap the get/set internals below — the public
 * API (NexusMemory.notes.add(), etc.) does not need to change.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const PREFIX = 'nexus:';
  const MAX_RECENT_COMMANDS = 25;
  const MAX_CHAT_HISTORY = 200;

  function readRaw(key, fallback) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (err) {
      console.warn(`[NexusMemory] failed to read "${key}", using fallback`, err);
      return fallback;
    }
  }

  function writeRaw(key, value) {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`[NexusMemory] failed to write "${key}"`, err);
      return false;
    }
  }

  function uid() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  const defaultPreferences = {
    name: '',
    theme: 'dark',
    language: 'en',
    animationQuality: 'high',
    soundEffects: true,
    voiceURI: '',
    assistantName: 'FRANK', // 'FRANK' or 'KEVINE' — see settings.js
    voiceModeEnabled: false, // "Hey FRANK" wake-phrase listening
  };

  const NexusMemory = {
    async init() {
      // Ensure preference object always has every key (handles upgrades
      // from an older Phase 1 version gracefully).
      const current = readRaw('preferences', {});
      writeRaw('preferences', Object.assign({}, defaultPreferences, current));
    },

    preferences: {
      get() {
        return Object.assign({}, defaultPreferences, readRaw('preferences', {}));
      },
      set(patch) {
        const next = Object.assign({}, NexusMemory.preferences.get(), patch);
        writeRaw('preferences', next);
        NexusCore.bus.emit('memory:preferences-changed', next);
        return next;
      },
    },

    notes: {
      all() {
        return readRaw('notes', []);
      },
      add(text) {
        const list = NexusMemory.notes.all();
        const entry = { id: uid(), text, createdAt: new Date().toISOString() };
        list.unshift(entry);
        writeRaw('notes', list);
        NexusCore.bus.emit('memory:notes-changed', list);
        return entry;
      },
      remove(id) {
        const list = NexusMemory.notes.all().filter((n) => n.id !== id);
        writeRaw('notes', list);
        NexusCore.bus.emit('memory:notes-changed', list);
      },
    },

    reminders: {
      all() {
        return readRaw('reminders', []);
      },
      add(text, when) {
        const list = NexusMemory.reminders.all();
        const entry = { id: uid(), text, when: when || null, createdAt: new Date().toISOString() };
        list.unshift(entry);
        writeRaw('reminders', list);
        NexusCore.bus.emit('memory:reminders-changed', list);
        return entry;
      },
      remove(id) {
        const list = NexusMemory.reminders.all().filter((r) => r.id !== id);
        writeRaw('reminders', list);
        NexusCore.bus.emit('memory:reminders-changed', list);
      },
    },

    tasks: {
      all() {
        return readRaw('tasks', []);
      },
      add(text) {
        const list = NexusMemory.tasks.all();
        const entry = { id: uid(), text, done: false, createdAt: new Date().toISOString() };
        list.unshift(entry);
        writeRaw('tasks', list);
        NexusCore.bus.emit('memory:tasks-changed', list);
        return entry;
      },
      toggle(id) {
        const list = NexusMemory.tasks.all().map((t) => (t.id === id ? { ...t, done: !t.done } : t));
        writeRaw('tasks', list);
        NexusCore.bus.emit('memory:tasks-changed', list);
      },
      remove(id) {
        const list = NexusMemory.tasks.all().filter((t) => t.id !== id);
        writeRaw('tasks', list);
        NexusCore.bus.emit('memory:tasks-changed', list);
      },
    },

    recentCommands: {
      all() {
        return readRaw('recentCommands', []);
      },
      add(text) {
        const list = NexusMemory.recentCommands.all();
        list.unshift({ id: uid(), text, at: new Date().toISOString() });
        writeRaw('recentCommands', list.slice(0, MAX_RECENT_COMMANDS));
        NexusCore.bus.emit('memory:commands-changed', list.slice(0, MAX_RECENT_COMMANDS));
      },
    },

    /** Tracks the single most recent *matched* command, for "continue last task". */
    lastTask: {
      get() {
        return readRaw('lastTask', null);
      },
      set(id, text) {
        const entry = { id, text, at: new Date().toISOString() };
        writeRaw('lastTask', entry);
        return entry;
      },
    },

    chatHistory: {
      all() {
        return readRaw('chatHistory', []);
      },
      add(role, text) {
        const list = NexusMemory.chatHistory.all();
        list.push({ role, text, at: new Date().toISOString() });
        writeRaw('chatHistory', list.slice(-MAX_CHAT_HISTORY));
      },
      clear() {
        writeRaw('chatHistory', []);
      },
    },

    /** Raw accessors — used by auth.js for the passcode hash/salt only. */
    raw: { read: readRaw, write: writeRaw },

    /** Export everything except the auth hash (no point exporting a secret). */
    exportAll() {
      const dump = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(PREFIX) && key !== PREFIX + 'auth') {
          dump[key] = JSON.parse(localStorage.getItem(key));
        }
      }
      return dump;
    },

    importAll(dump) {
      Object.keys(dump || {}).forEach((key) => {
        if (key.startsWith(PREFIX) && key !== PREFIX + 'auth') {
          localStorage.setItem(key, JSON.stringify(dump[key]));
        }
      });
      NexusCore.bus.emit('memory:imported');
    },

    /** Wipe every nexus:* key. Does NOT touch unrelated site storage. */
    resetAll(keepAuth) {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(PREFIX)) keys.push(key);
      }
      keys.forEach((key) => {
        if (keepAuth && key === PREFIX + 'auth') return;
        localStorage.removeItem(key);
      });
      NexusCore.bus.emit('memory:reset');
    },
  };

  global.NexusMemory = NexusCore.register('memory', NexusMemory);
})(window);
