/**
 * command-engine.js
 * -----------------------------------------------------------------------
 * A small, data-driven command router. Each command is:
 *   { id, patterns: [keywords/phrases], handler: (matchedText) => void }
 *
 * parseAndRun(text) does simple, transparent keyword matching (no
 * external NLP service, no network call — everything resolves locally).
 * It picks the command whose pattern list has the longest matching
 * phrase found in the input, so more specific phrases win over generic
 * ones (e.g. "open ai chat" beats a bare "open").
 *
 * New commands can be added at runtime via NexusCommands.register(),
 * which is exactly what components/*.js do for their own panels —
 * the engine itself has no knowledge of camera/calculator/etc.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const registry = [];

  function normalize(text) {
    return (text || '').toLowerCase().trim();
  }

  const NexusCommands = {
    async init() {
      // Load the starter command set from data/commands.json so the
      // list is data-driven and easy to extend without touching code.
      try {
        const res = await fetch('data/commands.json');
        if (res.ok) {
          const defs = await res.json();
          defs.forEach((def) => {
            // Handlers for these built-ins are wired up in app.js /
            // components, which call register() again with the real
            // handler once the DOM exists. This just seeds metadata
            // (id + patterns) so command discovery works immediately.
            if (!registry.find((c) => c.id === def.id)) {
              registry.push({ id: def.id, patterns: def.patterns, handler: null, label: def.label });
            }
          });
        }
      } catch (err) {
        console.warn('[NexusCommands] could not load data/commands.json (offline first run?)', err);
      }
    },

    /** Register or upgrade a command with a real handler function. */
    register(id, patterns, handler, label) {
      const existing = registry.find((c) => c.id === id);
      if (existing) {
        existing.patterns = patterns || existing.patterns;
        existing.handler = handler;
        if (label) existing.label = label;
      } else {
        registry.push({ id, patterns, handler, label: label || id });
      }
    },

    list() {
      return registry.map((c) => ({ id: c.id, label: c.label, patterns: c.patterns }));
    },

    /** Finds the best-matching registered command for free text and runs it. */
    parseAndRun(text) {
      const input = normalize(text);
      if (!input) return { matched: false };

      let best = null;
      let bestLen = 0;
      for (const cmd of registry) {
        for (const pattern of cmd.patterns) {
          const p = normalize(pattern);
          if (input.includes(p) && p.length > bestLen) {
            best = cmd;
            bestLen = p.length;
          }
        }
      }

      NexusMemory.recentCommands.add(text);

      if (best && typeof best.handler === 'function') {
        best.handler(text);
        NexusCore.bus.emit('commands:executed', { id: best.id, text });
        // Don't let "continue last task" overwrite itself as the last task.
        if (best.id !== 'continue-last-task') {
          NexusMemory.lastTask.set(best.id, text);
        }
        return { matched: true, id: best.id };
      }

      NexusCore.bus.emit('commands:unmatched', text);
      return { matched: false };
    },
  };

  global.NexusCommands = NexusCore.register('commands', NexusCommands);
})(window);
