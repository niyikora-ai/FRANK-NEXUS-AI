/**
 * live-data.js
 * -----------------------------------------------------------------------
 * Replaces the Phase 1 demo numbers with real browser-reported values,
 * where the platform exposes them. Every source here is read-only and
 * requires no extra permission prompt beyond what the browser already
 * grants a page:
 *   - time / date: system clock
 *   - battery: navigator.getBattery() (Chromium-based browsers only;
 *     deprecated/removed in some engines for privacy reasons — we
 *     degrade gracefully if it's missing)
 *   - network: navigator.onLine + the Network Information API
 *     (navigator.connection), where supported
 *   - device: navigator.deviceMemory / navigator.hardwareConcurrency,
 *     where supported
 *
 * Nothing here is sent off the device; it only updates the dashboard UI.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const NexusLiveData = {
    async init() {
      this._battery = null;
      if (navigator.getBattery) {
        try {
          this._battery = await navigator.getBattery();
        } catch (err) {
          this._battery = null;
        }
      }
    },

    now() {
      const d = new Date();
      return {
        time: d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        date: d.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
      };
    },

    battery() {
      if (!this._battery) return null;
      return {
        level: Math.round(this._battery.level * 100),
        charging: this._battery.charging,
      };
    },

    network() {
      const online = navigator.onLine;
      const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
      return {
        online,
        type: conn && conn.effectiveType ? conn.effectiveType.toUpperCase() : (online ? 'ONLINE' : 'OFFLINE'),
      };
    },

    device() {
      return {
        memoryGB: navigator.deviceMemory || null,
        cores: navigator.hardwareConcurrency || null,
        platform: navigator.platform || navigator.userAgentData?.platform || 'unknown',
      };
    },
  };

  global.NexusLiveData = NexusCore.register('liveData', NexusLiveData);
})(window);
