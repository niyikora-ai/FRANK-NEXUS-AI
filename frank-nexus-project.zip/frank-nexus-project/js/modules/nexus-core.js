/**
 * nexus-core.js
 * -----------------------------------------------------------------------
 * The coordination layer for FRANK NEXUS AI.
 *
 * Responsibilities:
 *  - Provide a tiny pub/sub event bus so modules never call each other
 *    directly (keeps everything swappable / testable).
 *  - Hold a registry of modules so app.js can boot them in order.
 *  - Expose NexusCore.init() as the single entry point called once the
 *    lock screen is passed.
 *
 * No other module should reach into the DOM before NexusCore.init() has
 * fired the 'nexus:ready' event — that's the signal that memory,
 * permissions, settings, voice and the command engine have all finished
 * loading their saved state.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  const listeners = Object.create(null);
  const modules = Object.create(null);
  let ready = false;

  const bus = {
    /** Subscribe to an event. Returns an unsubscribe function. */
    on(event, handler) {
      (listeners[event] || (listeners[event] = [])).push(handler);
      return () => bus.off(event, handler);
    },
    off(event, handler) {
      if (!listeners[event]) return;
      listeners[event] = listeners[event].filter((h) => h !== handler);
    },
    /** Fire an event with an optional payload. */
    emit(event, payload) {
      (listeners[event] || []).slice().forEach((handler) => {
        try {
          handler(payload);
        } catch (err) {
          console.error(`[NexusCore] listener for "${event}" threw:`, err);
        }
      });
    },
  };

  const NexusCore = {
    bus,

    /** Register a module by name so other code can find it without a global. */
    register(name, api) {
      modules[name] = api;
      return api;
    },

    get(name) {
      return modules[name];
    },

    isReady() {
      return ready;
    },

    /**
     * Boot sequence. Called once, right after a successful unlock.
     * Each module's own init() is responsible for loading its saved
     * state from NexusMemory — nexus-core just sequences the calls
     * and reports readiness.
     */
    async init() {
      const bootOrder = ['memory', 'settings', 'permissions', 'commands', 'voice', 'animations'];
      for (const name of bootOrder) {
        const mod = modules[name];
        if (mod && typeof mod.init === 'function') {
          try {
            await mod.init();
          } catch (err) {
            console.error(`[NexusCore] "${name}" failed to init:`, err);
          }
        }
      }
      ready = true;
      bus.emit('nexus:ready');
    },
  };

  global.NexusCore = NexusCore;
})(window);
