/**
 * animations.js
 * -----------------------------------------------------------------------
 * Small, focused animation helpers. Everything here uses CSS classes
 * driven by transform/opacity (cheap for the compositor) rather than
 * layout-triggering properties, and any per-frame JS work goes through
 * requestAnimationFrame so it stays in sync with the browser's paint
 * cycle instead of running on a setInterval.
 * -----------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  let coreEl = null;
  let rafId = null;

  const NexusAnimations = {
    async init() {
      coreEl = document.querySelector('.core');
    },

    setListening(isListening) {
      if (!coreEl) return;
      coreEl.classList.toggle('listening', isListening);
    },

    setSpeaking(isSpeaking) {
      if (!coreEl) return;
      coreEl.classList.toggle('speaking', isSpeaking);
    },

    setThinking(isThinking) {
      if (!coreEl) return;
      coreEl.classList.toggle('thinking', isThinking);
    },

    /**
     * Runs `frameFn(timestamp)` on every animation frame until it returns
     * false, or until stopLoop() is called. Used for things like a live
     * voice waveform — kept generic so any module can reuse it instead of
     * rolling its own setInterval.
     */
    startLoop(frameFn) {
      NexusAnimations.stopLoop();
      const step = (ts) => {
        const keepGoing = frameFn(ts);
        if (keepGoing !== false) rafId = requestAnimationFrame(step);
      };
      rafId = requestAnimationFrame(step);
    },

    stopLoop() {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = null;
    },

    toast(message, duration = 2200) {
      let el = document.getElementById('nexus-toast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'nexus-toast';
        el.className = 'toast';
        document.body.appendChild(el);
      }
      el.textContent = message;
      el.classList.add('show');
      clearTimeout(NexusAnimations._toastTimer);
      NexusAnimations._toastTimer = setTimeout(() => el.classList.remove('show'), duration);
    },
  };

  global.NexusAnimations = NexusCore.register('animations', NexusAnimations);
})(window);
